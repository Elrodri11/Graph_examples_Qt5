#include <QApplication>
#include <QWidget>
#include <QLineEdit>
#include <QPushButton>
#include <QVBoxLayout>
#include <QGraphicsView>
#include <QGraphicsScene>
#include <QGraphicsEllipseItem>
#include <QGraphicsTextItem>
#include <QPointF>
#include <QPen>
#include <QPainterPath>
#include <cmath>
#include <QDebug>

class GraphWidget : public QGraphicsView {
public:
    GraphWidget(QWidget *parent = nullptr) : QGraphicsView(parent) {
        scene = new QGraphicsScene(this);
        setScene(scene);
        scene->setSceneRect(-250, -250, 500, 500);
    }

    void drawGraph(const QString &graphText) {
        scene->clear();
        nodePositions.clear();

        QStringList lines = graphText.split('\n');
        for (const QString &line : lines) {
            QString cleanedLine = line.trimmed();
            cleanedLine.remove(QChar('>'));
            QStringList parts = cleanedLine.split("--");
            if (parts.size() == 3) {
                QString source = parts[0].trimmed();
                QString weight = parts[1].trimmed();
                QString dest = parts[2].trimmed();

                if (!nodePositions.contains(source))
                    nodePositions[source] = getRandomPosition();

                QPointF sourcePos = nodePositions[source];

                if (!nodePositions.contains(dest))
                    nodePositions[dest] = getRandomPosition();

                QPointF destPos = nodePositions[dest];

                if (source != dest) {
                    scene->addLine(sourcePos.x(), sourcePos.y(), destPos.x(), destPos.y(), QPen(Qt::black, 1));

                    drawArrowhead(sourcePos, destPos);
                    
                    QGraphicsTextItem *weightText = scene->addText(weight);
                    weightText->setScale(2);
                    weightText->setPos((sourcePos.x() + destPos.x()) / 2, (sourcePos.y() + destPos.y()) / 2);
                } else {
                    QPointF controlPoint1(sourcePos.x() - 100, sourcePos.y() - 100);
                    QPointF controlPoint2(sourcePos.x() + 100, sourcePos.y() - 100);
                    QPointF endPoint(sourcePos);

                    QPainterPath path;
                    path.moveTo(sourcePos);
                    path.cubicTo(controlPoint1, controlPoint2, endPoint);
                    scene->addPath(path, QPen(Qt::black, 1));

                    drawArrowhead(sourcePos, sourcePos);
                    
                    QGraphicsTextItem *weightText = scene->addText(weight);
                    weightText->setScale(2);
                    weightText->setPos(sourcePos.x() - 25, sourcePos.y() - 75);
                }

                QGraphicsEllipseItem *sourceNode = scene->addEllipse(sourcePos.x() - 30, sourcePos.y() - 30, 60, 60); 
                QGraphicsTextItem *sourceText = scene->addText(source);
                sourceText->setScale(2);
                sourceText->setPos(sourcePos.x() - 10, sourcePos.y() - 25);

                QGraphicsEllipseItem *destNode = scene->addEllipse(destPos.x() - 30, destPos.y() - 30, 60, 60);
                QGraphicsTextItem *destText = scene->addText(dest);
                destText->setScale(2); 
                destText->setPos(destPos.x() - 10, destPos.y() - 25);
            }
        }
    }

private:
    QGraphicsScene *scene;
    QMap<QString, QPointF> nodePositions;

    QPointF getRandomPosition() {
        qreal x, y;
        do {
            x = qreal(qrand() % 400 - 200);
            y = qreal(qrand() % 400 - 200);
        } while (isOverlapping(x, y));
        return QPointF(x, y);
    }

    bool isOverlapping(qreal x, qreal y) {
        for (const QPointF &pos : nodePositions) {
            if (qAbs(pos.x() - x) < 60 && qAbs(pos.y() - y) < 60) {
                return true;
            }
        }
        return false;
    }

    void drawArrowhead(const QPointF &start, const QPointF &end) {
        qreal angle = atan2(end.y() - start.y(), end.x() - start.x());

        QPointF arrowPoint1 = end - QPointF(cos(angle + M_PI / 6) * 20, sin(angle + M_PI / 6) * 20);
        QPointF arrowPoint2 = end - QPointF(cos(angle - M_PI / 6) * 20, sin(angle - M_PI / 6) * 20);

        scene->addLine(end.x(), end.y(), arrowPoint1.x(), arrowPoint1.y(), QPen(Qt::black, 1));
        scene->addLine(end.x(), end.y(), arrowPoint2.x(), arrowPoint2.y(), QPen(Qt::black, 1));
    }
};

class MainWindow : public QWidget {
public:
    MainWindow(QWidget *parent = nullptr) : QWidget(parent) {
        inputLineEdit = new QLineEdit(this);
        generateButton = new QPushButton("Generate", this);
        graphWidget = new GraphWidget(this);

        QVBoxLayout *layout = new QVBoxLayout(this);
        layout->addWidget(inputLineEdit);
        layout->addWidget(generateButton);
        layout->addWidget(graphWidget);
        setLayout(layout);

        connect(generateButton, &QPushButton::clicked, this, &MainWindow::generateGraph);
    }

private slots:
    void generateGraph() {
        QString graphText = inputLineEdit->text();
        graphWidget->drawGraph(graphText);
    }

private:
    QLineEdit *inputLineEdit;
    QPushButton *generateButton;
    GraphWidget *graphWidget;
};

int main(int argc, char *argv[]) {
    QApplication a(argc, argv);
    MainWindow w;
    w.show();
    return a.exec();
}
